const CATEGORIES = ["Food", "Transport", "Bills", "Shopping", "Education", "Entertainment", "Health", "Salary", "Freelance", "Investment", "Other"];
const money = value => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(value || 0));
const $ = id => document.getElementById(id);
let monthlyChart, categoryChart, allTransactions = [];
let toastTimer;

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || body.message || "Request failed");
  return body;
}

function showToast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2600);
}

function populateCategories() {
  $("formCategory").innerHTML = CATEGORIES.map(c => `<option>${c}</option>`).join("");
}

async function checkDatabase() {
  const dot = document.querySelector(".status-dot");
  try {
    await api("/api/health");
    $("dbStatus").textContent = "MySQL connected";
    dot.className = "status-dot ok";
  } catch {
    $("dbStatus").textContent = "Database disconnected";
    dot.className = "status-dot error";
  }
}

async function loadSummary() {
  const data = await api("/api/analytics/summary");
  $("totalIncome").textContent = money(data.totalIncome);
  $("totalExpenses").textContent = money(data.totalExpenses);
  $("balance").textContent = money(data.balance);
  $("savingsRate").textContent = `${Number(data.savingsRate).toFixed(1)}%`;
  $("transactionCount").textContent = `${data.transactionCount} transactions recorded`;
}

async function loadCharts() {
  const [monthly, categories] = await Promise.all([
    api("/api/analytics/monthly"),
    api("/api/analytics/categories")
  ]);
  const chartFont = { family: "DM Sans", size: 11 };
  if (monthlyChart) monthlyChart.destroy();
  monthlyChart = new Chart($("monthlyChart"), {
    type: "line",
    data: {
      labels: monthly.map(r => {
        const [year, month] = r.month.split("-");
        return new Date(Number(year), Number(month) - 1, 1).toLocaleDateString("en-IN", { month: "short", year: "2-digit" });
      }),
      datasets: [
        { label: "Income", data: monthly.map(r => Number(r.income)), borderColor: "#16845c", backgroundColor: "#16845c18", fill: true, tension: .35, pointRadius: 3 },
        { label: "Expenses", data: monthly.map(r => Number(r.expenses)), borderColor: "#d8874e", backgroundColor: "#d8874e12", fill: true, tension: .35, pointRadius: 3 }
      ]
    },
    options: { responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false }, plugins: { legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 7, font: chartFont } }, tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${money(ctx.raw)}` } } }, scales: { x: { grid: { display: false }, ticks: { font: chartFont } }, y: { beginAtZero: true, grid: { color: "#edf1ed" }, ticks: { font: chartFont, callback: v => `₹${Number(v).toLocaleString("en-IN")}` } } } }
  });
  if (categoryChart) categoryChart.destroy();
  categoryChart = new Chart($("categoryChart"), {
    type: "doughnut",
    data: {
      labels: categories.map(r => r.category),
      datasets: [{ data: categories.map(r => Number(r.total)), backgroundColor: ["#167a56", "#3c9a77", "#80c5a4", "#e2a06c", "#e9c58a", "#6786b7", "#8e78b6", "#7b9183", "#d77e72", "#a6c4c0", "#b4b8bf"], borderWidth: 2, borderColor: "#fff", hoverOffset: 5 }]
    },
    options: { responsive: true, maintainAspectRatio: false, cutout: "64%", plugins: { legend: { position: "bottom", labels: { usePointStyle: true, boxWidth: 7, padding: 14, font: chartFont } }, tooltip: { callbacks: { label: ctx => `${ctx.label}: ${money(ctx.raw)}` } } } }
  });
}

function setCategoryFilter(transactions) {
  const select = $("categoryFilter");
  const previous = select.value;
  const cats = [...new Set(transactions.map(t => t.category))].sort();
  select.innerHTML = '<option value="All">All categories</option>' + cats.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("");
  if (cats.includes(previous)) select.value = previous;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[ch]));
}

function renderTransactions(rows) {
  const tbody = $("transactionRows");
  $("resultCount").textContent = `${rows.length} record${rows.length === 1 ? "" : "s"}`;
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">No transactions found. Add a transaction to get started.</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(t => `
    <tr>
      <td><span class="transaction-title">${escapeHtml(t.title)}</span>${t.notes ? `<span class="transaction-note">${escapeHtml(t.notes)}</span>` : ""}</td>
      <td><span class="type-pill ${t.transaction_type.toLowerCase()}">${escapeHtml(t.transaction_type)}</span></td>
      <td>${escapeHtml(t.category)}</td>
      <td>${new Date(`${t.transaction_date}T00:00:00`).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</td>
      <td>${escapeHtml(t.payment_method || "Other")}</td>
      <td class="amount-cell">${t.transaction_type === "Expense" ? "−" : "+"}${money(t.amount)}</td>
      <td><button class="delete-btn" data-delete="${t.id}" aria-label="Delete transaction">×</button></td>
    </tr>`).join("");
}

async function loadTransactions() {
  const [all, filtered] = await Promise.all([
    api("/api/transactions"),
    api(`/api/transactions?${new URLSearchParams({
      type: $("typeFilter").value,
      category: $("categoryFilter").value,
      search: $("searchInput").value.trim()
    })}`)
  ]);
  allTransactions = all;
  setCategoryFilter(all);
  renderTransactions(filtered);
}

async function refreshAll() {
  try {
    await Promise.all([loadSummary(), loadCharts(), loadTransactions(), checkDatabase()]);
  } catch (error) {
    showToast(error.message);
    $("transactionRows").innerHTML = '<tr><td colspan="7" class="empty-cell">Could not load data. Check your MySQL connection and restart the server.</td></tr>';
  }
}

function openForm() {
  $("formMessage").textContent = "";
  $("transactionForm").reset();
  $("transactionForm").elements.transaction_date.value = new Date().toISOString().slice(0, 10);
  $("transactionDialog").showModal();
}
function closeForm() { $("transactionDialog").close(); }

$("openFormBtn").addEventListener("click", openForm);
$("closeFormBtn").addEventListener("click", closeForm);
$("cancelFormBtn").addEventListener("click", closeForm);
$("refreshBtn").addEventListener("click", refreshAll);
$("typeFilter").addEventListener("change", loadTransactions);
$("categoryFilter").addEventListener("change", loadTransactions);
$("searchInput").addEventListener("input", () => {
  clearTimeout(window.searchDebounce);
  window.searchDebounce = setTimeout(loadTransactions, 250);
});
$("transactionRows").addEventListener("click", async event => {
  const button = event.target.closest("[data-delete]");
  if (!button) return;
  if (!confirm("Delete this transaction permanently?")) return;
  try {
    await api(`/api/transactions/${button.dataset.delete}`, { method: "DELETE" });
    showToast("Transaction deleted.");
    await refreshAll();
  } catch (error) { showToast(error.message); }
});
$("transactionForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  data.amount = Number(data.amount);
  $("saveBtn").disabled = true;
  $("saveBtn").textContent = "Saving…";
  $("formMessage").textContent = "";
  try {
    await api("/api/transactions", { method: "POST", body: JSON.stringify(data) });
    closeForm();
    showToast("Transaction saved to MySQL.");
    await refreshAll();
  } catch (error) {
    $("formMessage").textContent = error.message;
  } finally {
    $("saveBtn").disabled = false;
    $("saveBtn").textContent = "Save transaction";
  }
});

populateCategories();
refreshAll();
