CREATE DATABASE IF NOT EXISTS expense_analytics;
USE expense_analytics;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    transaction_type ENUM('Income', 'Expense') NOT NULL DEFAULT 'Expense',
    category VARCHAR(60) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    transaction_date DATE NOT NULL,
    payment_method VARCHAR(40) DEFAULT 'Other',
    notes VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transaction_date (transaction_date),
    INDEX idx_category (category),
    INDEX idx_transaction_type (transaction_type)
);

-- Optional sample records. Run this section only if you want demo data.
INSERT INTO transactions
(title, transaction_type, category, amount, transaction_date, payment_method, notes)
VALUES
('Monthly stipend', 'Income', 'Salary', 18000, '2026-10-01', 'Bank Transfer', 'Demo income'),
('Groceries', 'Expense', 'Food', 1450, '2026-10-02', 'UPI', 'Weekly groceries'),
('Bus pass', 'Expense', 'Transport', 850, '2026-10-03', 'UPI', 'Monthly pass'),
('Internet bill', 'Expense', 'Bills', 799, '2026-10-05', 'UPI', 'Home internet'),
('Freelance design', 'Income', 'Freelance', 4500, '2026-10-08', 'Bank Transfer', 'Demo income'),
('Dinner', 'Expense', 'Food', 620, '2026-10-10', 'Card', 'Dinner with friends'),
('Course subscription', 'Expense', 'Education', 999, '2026-10-12', 'Card', 'Online course'),
('Movie', 'Expense', 'Entertainment', 450, '2026-10-15', 'UPI', 'Weekend movie');
