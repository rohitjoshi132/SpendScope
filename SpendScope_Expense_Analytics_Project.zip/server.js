require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "expense_analytics",
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true
});

const allowedTypes = new Set(["Income", "Expense"]);
const allowedPaymentMethods = new Set(["UPI", "Cash", "Card", "Bank Transfer", "Other"]);

app.get("/api/health", async (_req, res) => {
  try {
    const [rows] = await pool.query("SELECT 1 AS connected");
    res.json({ status: "ok", database: rows[0].connected === 1 });
  } catch (error) {
    res.status(500).json({ status: "error", message: "Cannot connect to MySQL. Check your .env settings." });
  }
});

app.get("/api/transactions", async (req, res) => {
  try {
    const { type, category, from, to, search } = req.query;
    const conditions = [];
    const values = [];

    if (type && allowedTypes.has(type)) {
      conditions.push("transaction_type = ?");
      values.push(type);
    }
    if (category && category !== "All") {
      conditions.push("category = ?");
      values.push(category);
    }
    if (from) {
      conditions.push("transaction_date >= ?");
      values.push(from);
    }
    if (to) {
      conditions.push("transaction_date <= ?");
      values.push(to);
    }
    if (search) {
      conditions.push("(title LIKE ? OR category LIKE ? OR notes LIKE ?)");
      values.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const [rows] = await pool.query(
      `SELECT id, title, transaction_type, category, amount,
              DATE_FORMAT(transaction_date, '%Y-%m-%d') AS transaction_date,
              payment_method, notes, created_at
       FROM transactions ${where}
       ORDER BY transaction_date DESC, id DESC`,
      values
    );
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not retrieve transactions." });
  }
});

app.post("/api/transactions", async (req, res) => {
  try {
    const { title, transaction_type, category, amount, transaction_date, payment_method, notes } = req.body;
    if (!title || !category || !transaction_date || !allowedTypes.has(transaction_type)) {
      return res.status(400).json({ error: "Title, category, date, and a valid transaction type are required." });
    }
    const parsedAmount = Number(amount);
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      return res.status(400).json({ error: "Amount must be a number greater than zero." });
    }
    const method = allowedPaymentMethods.has(payment_method) ? payment_method : "Other";
    const [result] = await pool.execute(
      `INSERT INTO transactions
       (title, transaction_type, category, amount, transaction_date, payment_method, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [String(title).trim(), transaction_type, String(category).trim(), parsedAmount, transaction_date, method, notes ? String(notes).trim() : null]
    );
    res.status(201).json({ id: result.insertId, message: "Transaction saved." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not save transaction. Check the database connection." });
  }
});

app.delete("/api/transactions/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: "Invalid transaction ID." });
    const [result] = await pool.execute("DELETE FROM transactions WHERE id = ?", [id]);
    if (!result.affectedRows) return res.status(404).json({ error: "Transaction not found." });
    res.json({ message: "Transaction deleted." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not delete transaction." });
  }
});

app.get("/api/analytics/summary", async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS totalIncome,
        COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS totalExpenses,
        COUNT(*) AS transactionCount
      FROM transactions
    `);
    const totalIncome = Number(rows[0].totalIncome);
    const totalExpenses = Number(rows[0].totalExpenses);
    res.json({
      totalIncome,
      totalExpenses,
      balance: totalIncome - totalExpenses,
      transactionCount: Number(rows[0].transactionCount),
      savingsRate: totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not calculate summary." });
  }
});

app.get("/api/analytics/monthly", async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT DATE_FORMAT(transaction_date, '%Y-%m') AS month,
        SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END) AS income,
        SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END) AS expenses
      FROM transactions
      GROUP BY DATE_FORMAT(transaction_date, '%Y-%m')
      ORDER BY month
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not calculate monthly analytics." });
  }
});

app.get("/api/analytics/categories", async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT category, SUM(amount) AS total
      FROM transactions
      WHERE transaction_type = 'Expense'
      GROUP BY category
      ORDER BY total DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not calculate category analytics." });
  }
});

app.get("/api/analytics/payment-methods", async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT payment_method, SUM(amount) AS total
      FROM transactions
      WHERE transaction_type = 'Expense'
      GROUP BY payment_method
      ORDER BY total DESC
    `);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not calculate payment analytics." });
  }
});

app.listen(PORT, () => {
  console.log(`Expense Analytics Dashboard running at http://localhost:${PORT}`);
});
