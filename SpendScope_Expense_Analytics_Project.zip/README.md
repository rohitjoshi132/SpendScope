# SpendScope — Expense Analytics Dashboard

A beginner-friendly data analytics mini-project using:
- **Frontend:** HTML5, CSS3, JavaScript
- **Charts:** Chart.js
- **Backend:** Node.js + Express
- **Database:** MySQL (managed using MySQL Workbench)

## Features
- Add and delete income/expense transactions
- Save transaction data in MySQL
- KPI cards: total income, expenses, net balance, savings rate
- Monthly income-vs-expenses line chart
- Expense category doughnut chart
- Search, category filter, and transaction-type filter
- Responsive layout for desktop and mobile
- MySQL connection status indicator

## Requirements
Install Node.js LTS and MySQL Server. MySQL Workbench is used to run SQL and inspect the database; the app connects to MySQL Server.

## Setup

### 1. Create the database
1. Open MySQL Workbench and connect to your local MySQL Server.
2. Open `database.sql`.
3. Execute the script using the lightning-bolt button.
4. The script creates `expense_analytics`, the `transactions` table, and sample rows.

### 2. Configure database credentials
1. In the project folder, copy `.env.example` to a new file named `.env`.
2. Update `DB_USER` and `DB_PASSWORD` to match your local MySQL account.
3. Keep `DB_NAME=expense_analytics` unless you changed the database name.

Example:
```env
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_actual_password
DB_NAME=expense_analytics
```
Do not share your `.env` file or publish your database password.

### 3. Install dependencies
Open Terminal in the project folder and run:
```bash
npm install
```

### 4. Start the application
```bash
npm start
```
Open this URL in your browser:
http://localhost:3000

Keep the terminal open while using the dashboard.

## How the data flows
Browser form → JavaScript `fetch()` → Express API → MySQL database → SQL aggregation endpoints → Chart.js and KPI cards.

## Suggested demo
1. Add an income transaction such as a stipend.
2. Add expenses in Food, Transport, and Education.
3. Observe the KPI cards and charts update.
4. Filter by transaction type or category.
5. Delete a demo transaction and confirm the dashboard refreshes.

## SQL analysis questions for your report
1. What is total income and total expenditure?
2. Which expense category has the highest spending?
3. How does income compare with expenses month by month?
4. Which payment method is used for the highest amount of expenses?
5. What is the net balance and savings rate?

Example queries:
```sql
USE expense_analytics;

-- Total income and expenses
SELECT transaction_type, SUM(amount) AS total
FROM transactions
GROUP BY transaction_type;

-- Spending by category
SELECT category, SUM(amount) AS total_spent
FROM transactions
WHERE transaction_type = 'Expense'
GROUP BY category
ORDER BY total_spent DESC;

-- Monthly income and expenses
SELECT DATE_FORMAT(transaction_date, '%Y-%m') AS month,
       SUM(CASE WHEN transaction_type='Income' THEN amount ELSE 0 END) AS income,
       SUM(CASE WHEN transaction_type='Expense' THEN amount ELSE 0 END) AS expenses
FROM transactions
GROUP BY month
ORDER BY month;

-- Expenses by payment method
SELECT payment_method, SUM(amount) AS total
FROM transactions
WHERE transaction_type = 'Expense'
GROUP BY payment_method
ORDER BY total DESC;
```

## Troubleshooting
- **Database disconnected:** Ensure MySQL Server is running and `.env` credentials are correct.
- **Access denied:** Confirm the MySQL username/password and privileges.
- **Unknown database:** Run `database.sql` in MySQL Workbench.
- **Cannot open page:** Confirm `npm start` is running and open `http://localhost:3000`.
- **Charts not loading:** Internet access is needed for the Chart.js CDN in this starter version.

## Academic project summary
**Title:** SpendScope: Personal Expense Analytics Dashboard

**Objective:** Build a web-based analytics tool that stores financial transactions in a relational database and converts them into meaningful KPIs and visualizations.

**Learning outcomes:** CRUD operations, REST APIs, SQL aggregation, database connectivity, data filtering, KPI calculation, and interactive charting.
